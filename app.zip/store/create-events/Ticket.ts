// 2. Ticket Store
import { create } from "zustand";

export interface Benefit {
  id: number;
  text: string;
}

export interface Ticket {
  id: number; // frontend temp id
  _id?: string; // optional MongoDB id
  ticketName: string;
  price: string;
  quantity: string;
  // Optional ticket sale window. Empty string = not set (sales are
  // always open). Stored as "YYYY-MM-DD" to match <input type="date">.
  saleStartDate: string;
  saleEndDate: string;
  // Tier category (early_access, vip, gate, etc). Defaults to
  // "standard" — matches the backend default so old tickets and
  // freshly-added ones both behave the same until explicitly changed.
  tierCategory: string;
  benefits: Benefit[];
  isExpanded: boolean;
  status: "Active" | "Inactive";
  soldCount: number;
}


interface TicketStore {
  tickets: Ticket[];

  addTicket: () => void;
  deleteTicket: (id: number) => void;
  updateTicket: <K extends keyof Ticket>(
    id: number,
    field: K,
    value: Ticket[K]
  ) => void;
  toggleExpand: (id: number) => void;
  addBenefit: (ticketId: number) => void;
  deleteBenefit: (ticketId: number, benefitId: number) => void;
  updateBenefit: (ticketId: number, benefitId: number, text: string) => void;
  
  initializeTickets: (initialTickets?: Ticket[]) => void;
  resetTickets: () => void;
  updateOrAddTicket: (ticket: Ticket) => void;

}

const defaultTicketState = {
  tickets: [
    {
      id: 1,
      ticketName: "Regular",
      price: "5000",
      quantity: "100",
      saleStartDate: "",
      saleEndDate: "",
      tierCategory: "standard",
      benefits: [{ id: 1, text: "" }],
      isExpanded: false,
      status: "Active" as const,
      soldCount: 0,
    },
  ],
};

export const useTicketStore = create<TicketStore>((set) => ({
  ...defaultTicketState,

  addTicket: () =>
    set((state) => ({
      tickets: [
        ...state.tickets,
        {
          id: Date.now(),
          ticketName: "",
          price: "",
          quantity: "",
          saleStartDate: "",
          saleEndDate: "",
          tierCategory: "standard",
          benefits: [{ id: Date.now(), text: "" }],
          isExpanded: true,
          status: "Inactive",
          soldCount: 0,
        },
      ],
    })),

  deleteTicket: (id) =>
    set((state) => ({
      tickets: state.tickets.filter((t) => t.id !== id),
    })),

  updateTicket: (id, field, value) =>
    set((state) => ({
      tickets: state.tickets.map((t) =>
        t.id === id ? { ...t, [field]: value } : t
      ),
    })),

  toggleExpand: (id) =>
    set((state) => ({
      tickets: state.tickets.map((t) =>
        t.id === id ? { ...t, isExpanded: !t.isExpanded } : t
      ),
    })),

  addBenefit: (ticketId) =>
    set((state) => ({
      tickets: state.tickets.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              benefits: [...t.benefits, { id: Date.now(), text: "" }],
            }
          : t
      ),
    })),

  deleteBenefit: (ticketId, benefitId) =>
    set((state) => ({
      tickets: state.tickets.map((t) =>
        t.id === ticketId && t.benefits.length > 1
          ? {
              ...t,
              benefits: t.benefits.filter((b) => b.id !== benefitId),
            }
          : t
      ),
    })),

  updateBenefit: (ticketId, benefitId, text) =>
    set((state) => ({
      tickets: state.tickets.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              benefits: t.benefits.map((b) =>
                b.id === benefitId ? { ...b, text } : b
              ),
            }
          : t
      ),
    })),

  initializeTickets: (initialTickets) =>
    set({
      tickets:
        initialTickets && initialTickets.length > 0
          ? initialTickets
          : defaultTicketState.tickets,
    }),

    updateOrAddTicket: (ticket: Ticket) =>
  set((state) => {
    // check if ticket already exists in state
    const index = state.tickets.findIndex((t) => t.id === ticket.id);

    if (index !== -1) {
      // ✅ update existing ticket in state
      const newTickets = [...state.tickets];
      newTickets[index] = { ...newTickets[index], ...ticket };
      return { tickets: newTickets };
    } else {
      // ✅ add new ticket
      return {
        tickets: [
          ...state.tickets,
          { ...ticket, id: Date.now() }, // generate temp id
        ],
      };
    }
  }),


  resetTickets: () => set(defaultTicketState),
}));